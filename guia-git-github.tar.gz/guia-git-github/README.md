# Guia de Locais e Eventos

Projeto acadêmico para praticar HTML, CSS, Git e GitHub.

## Estrutura

- `index.html` — página principal do guia.
- `css/style.css` — estilos da página.
- `.gitignore` — arquivos e pastas que não devem ser versionados.

## Objetivo da atividade

Criar um histórico legível no Git, trabalhar em uma branch de refatoração e publicar a alteração em um Pull Request.
